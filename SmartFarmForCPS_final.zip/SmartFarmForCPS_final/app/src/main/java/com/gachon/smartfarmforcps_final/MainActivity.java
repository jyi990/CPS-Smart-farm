package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //textView 3개 객체 참조(수확량, 온도, 내일 온도)
    //TextView yieldTextView=findViewById(R.id.yieldRel);
    //TextView temperatureTextView=findViewById(R.id.temperatureTomRel);
    //TextView temperatureTomTextView=findViewById(R.id.temperatureControlTom);

    //서버로부터 받아올 값-아니 왜 코드가 포함되면 오류가 나는지 모르겠어요..
    //String todayYield="a";
    //String temperature="b";
    //String tomorrowTemperature="c";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //서버 값을 받아와 주세요...




        //값들을 연결하여 화면 상에 띄움
        //yieldTextView.setText(todayYield);
        //temperatureTextView.setText(temperature);
        //temperatureTomTextView.setText(tomorrowTemperature);


        //user 버튼 이벤트


        //온도 센서 버튼 이벤트
        Button temperatureButton=findViewById(R.id.temperatureSensorButton);
        temperatureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent temperatureIntent=new Intent(getApplicationContext(),TemperatureSensorActivity.class);
                startActivity(temperatureIntent);
            }
        });

        //습도 센서 버튼 이벤트
        Button humidityButton=findViewById(R.id.humiditySensorButton);
        humidityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent humidityIntent=new Intent(getApplicationContext(),HumiditySensorActivity.class);
                startActivity(humidityIntent);
            }
        });

        //조도 센서 버튼 이벤트
        Button lighteningButton=findViewById(R.id.lighteningSensorButton);
        lighteningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lighteningIntent=new Intent(getApplicationContext(),LighteningSensorActivity.class);
                startActivity(lighteningIntent);
            }
        });

        //수분 센서 버튼 이벤트
        Button moistureButton=findViewById(R.id.moistureSensorButton);
        moistureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moistureIntent=new Intent(getApplicationContext(),MoistureSensorActivity.class);
                startActivity(moistureIntent);
            }
        });

        //LED 버튼 이벤트
        Button ledButton=findViewById(R.id.ledButton);
        ledButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ledIntent=new Intent(getApplicationContext(),LEDActivity.class);
                startActivity(ledIntent);
            }
        });

        //home 버튼 이벤트
        Button homeButton=findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(homeIntent);
            }
        });
        //상태 확인 버튼 이벤트
        Button statusCheckButton=findViewById(R.id.stateButton);
        statusCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent statusCheckIntent=new Intent(getApplicationContext(),StatusCheckActivity.class);
                startActivity(statusCheckIntent);
            }
        });

        //머신러닝 버튼 이벤트
        Button machineLearningButton=findViewById(R.id.machineLearningButton);
        machineLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent machineLearningIntent=new Intent(getApplicationContext(),MachineLearningActivity.class);
                startActivity(machineLearningIntent);
            }
        });

        //강화학습 버튼 이벤트
        Button reinforcementLearningButton=findViewById(R.id.reinforcementButton);
        reinforcementLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reinforcementLearningIntent=new Intent(getApplicationContext(),ReinforcementActivity.class);
                startActivity(reinforcementLearningIntent);
            }
        });
    }
}