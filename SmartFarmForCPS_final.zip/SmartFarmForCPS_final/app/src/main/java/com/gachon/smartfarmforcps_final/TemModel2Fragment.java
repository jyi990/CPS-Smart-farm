package com.gachon.smartfarmforcps_final;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class TemModel2Fragment extends Fragment {

    private View view;

    public static TemModel2Fragment newInstance(){
        TemModel2Fragment temModel2Fragment=new TemModel2Fragment();
        return temModel2Fragment;
    }

    @NonNull
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_tem_model2, container, false);
        return view;
    }
}