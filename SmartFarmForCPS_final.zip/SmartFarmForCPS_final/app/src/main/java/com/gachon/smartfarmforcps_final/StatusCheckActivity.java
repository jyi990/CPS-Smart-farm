package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StatusCheckActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_check);

        //home 버튼 이벤트
        Button homeButton=findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(homeIntent);
            }
        });
        //상태 확인 버튼 이벤트
        Button statusCheckButton=findViewById(R.id.stateButton);
        statusCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent statusCheckIntent=new Intent(getApplicationContext(),StatusCheckActivity.class);
                startActivity(statusCheckIntent);
            }
        });

        //머신러닝 버튼 이벤트
        Button machineLearningButton=findViewById(R.id.machineLearningButton);
        machineLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent machineLearningIntent=new Intent(getApplicationContext(),MachineLearningActivity.class);
                startActivity(machineLearningIntent);
            }
        });

        //강화학습 버튼 이벤트
        Button reinforcementLearningButton=findViewById(R.id.reinforcementButton);
        reinforcementLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reinforcementLearningIntent=new Intent(getApplicationContext(),ReinforcementActivity.class);
                startActivity(reinforcementLearningIntent);
            }
        });
    }
}