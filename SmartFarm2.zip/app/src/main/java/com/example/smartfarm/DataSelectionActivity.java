package com.example.smartfarm;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DataSelectionActivity extends AppCompatActivity {

    //Textview textView;

    String[] items={"0.1","0.15","0.2","0.25,0.3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_selection);

        //textView=findViewById(R.id.textView);

        //Spinner spinner=findViewById(R.id.spinner);
        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(
         //       this, android.R.layout.simple_spinner_item,items);
        //adapter.setDropDownViewResource(
        //        android.R.layout.simple_spinner_dropdown_item);
        //)


    }
}