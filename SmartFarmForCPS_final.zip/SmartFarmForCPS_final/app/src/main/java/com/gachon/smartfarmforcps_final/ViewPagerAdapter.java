package com.gachon.smartfarmforcps_final;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.ArrayList;

public class ViewPagerAdapter extends FragmentPagerAdapter {
    public ViewPagerAdapter(@NonNull FragmentManager fm){
        super(fm);

    }

    //프레그먼트 교체 처리를 구현한 것
    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch(position){
            case 0:
                return TemModel1Fragment.newInstance();
            case 1:
                return TemModel2Fragment.newInstance();
            case 2:
                return TemModel3Fragment.newInstance();
            case 3:
                return TemModel4Fragment.newInstance();
            case 4:
                return TemModel5Fragment.newInstance();
            case 5:
                return TemModel6Fragment.newInstance();
            default:
                return null;

        }
    }


    @Override
    public int getCount() {
        return 6;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position){
        switch(position){
            case 0:
                return "1";
            case 1:
                return "2";
            case 2:
                return "3";
            case 3:
                return "4";
            case 4:
                return "5";
            case 5:
                return "6";
            default:
                return null;

        }
    }
}
