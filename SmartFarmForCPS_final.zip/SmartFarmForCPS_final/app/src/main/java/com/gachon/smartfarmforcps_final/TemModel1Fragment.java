package com.gachon.smartfarmforcps_final;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class TemModel1Fragment extends Fragment {

    private View view;

    public static TemModel1Fragment newInstance(){
        TemModel1Fragment temModel1Fragment=new TemModel1Fragment();
        return temModel1Fragment;
    }


    @NonNull
    @Override
    public View onCreateView(@NonNull  LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_tem_model1, container, false);
        return view;
    }
}