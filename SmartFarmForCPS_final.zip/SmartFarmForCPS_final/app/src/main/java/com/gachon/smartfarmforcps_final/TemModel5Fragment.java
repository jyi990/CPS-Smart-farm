package com.gachon.smartfarmforcps_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class TemModel5Fragment extends Fragment {

    private View view;

    public static TemModel5Fragment newInstance(){
        TemModel5Fragment temModel5Fragment=new TemModel5Fragment();
        return temModel5Fragment;
    }


    @NonNull
    @Override
    public View onCreateView(@NonNull  LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_tem_model5, container, false);
        return view;
    }
}