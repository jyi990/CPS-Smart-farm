package com.gachon.smartfarmforcps_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class YieldModel1Fragment extends Fragment {

    private View view;

    public static YieldModel1Fragment newInstance(){
        YieldModel1Fragment yieldModel1Fragment=new YieldModel1Fragment();
        return yieldModel1Fragment;
    }


    @NonNull
    @Override
    public View onCreateView(@NonNull  LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_yield_model1, container, false);
        return view;
    }
}