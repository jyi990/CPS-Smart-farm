package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;

public class MachineLearningActivity extends AppCompatActivity {

    private FragmentPagerAdapter fragmentPagerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_machine_learning);

        ViewPager viewPager= findViewById(R.id.viewPager);
        fragmentPagerAdapter=new ViewPagerAdapter(getSupportFragmentManager());

        TabLayout tabLayout=findViewById(R.id.tabLayout);
        viewPager.setAdapter(fragmentPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);

        //온도 버튼 이벤트
        Button temperatureButton=findViewById(R.id.temperatureButton);
        temperatureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent temperatureIntent=new Intent(getApplicationContext(),MachineLearningActivity.class);
                startActivity(temperatureIntent);
            }
        });

        //수확량 버튼 이벤트
        Button yieldButton=findViewById(R.id.yieldPredictionButton);
        yieldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent yieldIntent=new Intent(getApplicationContext(),MachineLearningYieldActivity.class);
                startActivity(yieldIntent);
            }
        });


    }
}