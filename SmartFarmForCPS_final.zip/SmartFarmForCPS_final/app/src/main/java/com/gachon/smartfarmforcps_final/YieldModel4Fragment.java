package com.gachon.smartfarmforcps_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class YieldModel4Fragment extends Fragment {

    private View view;

    public static YieldModel4Fragment newInstance(){
        YieldModel4Fragment yieldModel4Fragment=new YieldModel4Fragment();
        return yieldModel4Fragment;
    }


    @NonNull
    @Override
    public View onCreateView(@NonNull  LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_yield_model4, container, false);
        return view;
    }
}