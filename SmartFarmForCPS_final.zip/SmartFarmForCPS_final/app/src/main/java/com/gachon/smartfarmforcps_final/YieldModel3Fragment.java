package com.gachon.smartfarmforcps_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class YieldModel3Fragment extends Fragment {

    private View view;

    public static YieldModel3Fragment newInstance(){
        YieldModel3Fragment yieldModel3Fragment=new YieldModel3Fragment();
        return yieldModel3Fragment;
    }


    @NonNull
    @Override
    public View onCreateView(@NonNull  LayoutInflater inflater, @NonNull ViewGroup container,
                             @NonNull Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_yield_model3, container, false);
        return view;
    }
}