package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TemperatureSensorActivity extends AppCompatActivity {

    private final ImageView onButton=findViewById(R.id.onbutton);
    private final ImageView offButton=findViewById(R.id.offbutton);

    //센서값, 비교값 객체
    TextView sensorValue=findViewById(R.id.currentValRel);
    TextView compareValue=findViewById(R.id.compareRel);

    //서버에서 받아올 센서값, 비교값
    String sensorValueFromServer="";
    int compareVal=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_sensor);

        if(sensorState()) {
            onButton.setVisibility(ImageView.VISIBLE);
            offButton.setVisibility(ImageView.INVISIBLE);
        }
        else{
            onButton.setVisibility(ImageView.INVISIBLE);
            offButton.setVisibility(ImageView.VISIBLE);
        }


        //sensorValue.setText(sensorValueFromServer);

        //전일과 비교한 값을 보여주는 변수
        //계산하는 과정 추가 필요
        compareVal=calculateCompareVal();
       //compareValue.setText(compareVal);

        //home 버튼 이벤트
        Button homeButton=findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(homeIntent);
            }
        });
        //상태 확인 버튼 이벤트
        Button statusCheckButton=findViewById(R.id.stateButton);
        statusCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent statusCheckIntent=new Intent(getApplicationContext(),StatusCheckActivity.class);
                startActivity(statusCheckIntent);
            }
        });

        //머신러닝 버튼 이벤트
        Button machineLearningButton=findViewById(R.id.machineLearningButton);
        machineLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent machineLearningIntent=new Intent(getApplicationContext(),MachineLearningActivity.class);
                startActivity(machineLearningIntent);
            }
        });

        //강화학습 버튼 이벤트
        Button reinforcementLearningButton=findViewById(R.id.reinforcementButton);
        reinforcementLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reinforcementLearningIntent=new Intent(getApplicationContext(),ReinforcementActivity.class);
                startActivity(reinforcementLearningIntent);
            }
        });

    }
    //함수 기능 추가 필요
    private boolean sensorState() {
        return true;
    }

    private int calculateCompareVal(){
        int compareVal=0;
        return  compareVal;
    }
}