package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ReinforcementActivity extends AppCompatActivity {

    /*
    private TextView sensorName1=findViewById(R.id.sensorName1);
    private TextView sensorName2=findViewById(R.id.sensorName2);
    private TextView sensorName3=findViewById(R.id.sensorName3);
    private TextView sensorName4=findViewById(R.id.sensorName4);
    private TextView sensorName5=findViewById(R.id.sensorName5);
    private TextView sensorName6=findViewById(R.id.sensorName6);

    private TextView sensorSate1=findViewById(R.id.sensorState1);
    private TextView sensorSate2=findViewById(R.id.sensorState2);
    private TextView sensorSate3=findViewById(R.id.sensorState3);
    private TextView sensorSate4=findViewById(R.id.sensorState4);
    private TextView sensorSate5=findViewById(R.id.sensorState5);
    private TextView sensorSate6=findViewById(R.id.sensorState6);

    private TextView sensorValue1=findViewById(R.id.sensorValue1);
    private TextView sensorValue2=findViewById(R.id.sensorValue2);
    private TextView sensorValue3=findViewById(R.id.sensorValue3);
    private TextView sensorValue4=findViewById(R.id.sensorValue4);
    private TextView sensorValue5=findViewById(R.id.sensorValue5);
    private TextView sensorValue6=findViewById(R.id.sensorValue6);

     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reinforcement);

        ArrayList<String> sensor = new ArrayList<String>();
        //setText();


        //home 버튼 이벤트
        Button homeButton=findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(homeIntent);
            }
        });
        //상태 확인 버튼 이벤트
        Button statusCheckButton=findViewById(R.id.stateButton);
        statusCheckButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent statusCheckIntent=new Intent(getApplicationContext(),StatusCheckActivity.class);
                startActivity(statusCheckIntent);
            }
        });

        //머신러닝 버튼 이벤트
        Button machineLearningButton=findViewById(R.id.machineLearningButton);
        machineLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent machineLearningIntent=new Intent(getApplicationContext(),MachineLearningActivity.class);
                startActivity(machineLearningIntent);
            }
        });

        //강화학습 버튼 이벤트
        Button reinforcementLearningButton=findViewById(R.id.reinforcementButton);
        reinforcementLearningButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent reinforcementLearningIntent=new Intent(getApplicationContext(),ReinforcementActivity.class);
                startActivity(reinforcementLearningIntent);
            }
        });
    }
}