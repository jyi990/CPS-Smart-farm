package com.example.smartfarm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //상태 확인 버튼
        Button statusCheckButton = (Button) findViewById(R.id.statusCheckButton);
        statusCheckButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), StatusCheckActivity.class);
                startActivity(intent);
            }
        });

        //머신 러닝 버튼
        Button machineLearningButton = (Button) findViewById(R.id.machineLearningButton);
        machineLearningButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MachineLearningChooseActivity.class);
                startActivity(intent);
            }
        });

        //상태 제어 버튼
        Button statusControlButton = (Button) findViewById(R.id.statusControlButton);
        statusControlButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), StatusControlActivity.class);
                startActivity(intent);
            }
        });

        //강화 학습 버튼
        Button reinforcementButton = (Button) findViewById(R.id.reinforcementButton);
        reinforcementButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ReinforcementSettingActivity.class);
                startActivity(intent);
            }
        });
    }
}