package com.gachon.smartfarmforcps_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class StatusCheckActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status_check);
    }
}